﻿$sourceDir = "C:\Users\Alam M\alam-m"
$zipPath = "C:\Users\Alam M\backup-alam-m-20260830-db7da60.zip"

if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

$tempBackupDir = "C:\Users\Alam M\temp_backup_pkg"
if (Test-Path $tempBackupDir) {
    Remove-Item $tempBackupDir -Recurse -Force
}
New-Item -ItemType Directory -Path $tempBackupDir | Out-Null

Get-ChildItem -Path $sourceDir -Exclude "node_modules", ".output", ".nitro", "dist" | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $tempBackupDir -Recurse -Force
}

Compress-Archive -Path "$tempBackupDir\*" -DestinationPath $zipPath -CompressionLevel Optimal
Remove-Item $tempBackupDir -Recurse -Force

$zipItem = Get-Item $zipPath
Write-Host "ZIP Backup created successfully at: $($zipItem.FullName)"
Write-Host "Size: $([math]::Round($zipItem.Length / 1MB, 2)) MB"
